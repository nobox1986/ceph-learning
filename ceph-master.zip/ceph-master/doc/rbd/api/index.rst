========================
 Ceph Block Device APIs
========================

.. toctree::
   :maxdepth: 2

   librbd (Python) <librbdpy>
