Repairing PG inconsistencies
============================


