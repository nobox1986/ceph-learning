====================================
 Downloading a Ceph Release Tarball
====================================

As Ceph development progresses, the Ceph team releases new versions of the
source code. You may download source code tarballs for Ceph releases here:

`Ceph Release Tarballs`_

.. tip:: For international users: There might be a mirror close to you where download Ceph from. For more information see: `Ceph Mirrors`_.


.. _Ceph Release Tarballs: https://download.ceph.com/tarballs/
.. _Ceph Mirrors: ../mirrors
